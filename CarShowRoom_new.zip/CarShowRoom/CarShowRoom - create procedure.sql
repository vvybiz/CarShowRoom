
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
--------------------------------------------------------------------
������� ��������� � ������������� : YearSales

��������� ������ ������ (F5)
--------------------------------------------------------------------
*/
CREATE PROCEDURE YearSales 
(@YearSales int)

AS

BEGIN

if  Object_ID('CarShowRoom.dbo.YST') is not null
  drop table [CarShowRoom].[dbo].[YST];
	

select list.brand_name +' '+ list.model_name as [������], isnull(January,0) as [������], isnull(February,0) as [�������], isnull(March,0) as [����], 
	isnull(April,0) as [������], isnull(May,0) as [���], isnull(June,0) as [����], isnull(July,0) as [����], isnull(August,0) as [������], 
		isnull(September,0) as [��������], isnull(October,0) as [�������], isnull(November,0) as [������], isnull(December,0) as [�������] 
			into [CarShowRoom].[dbo].[YST] from 
(select brand_name, model_name from [CarShowRoom].[production].[brands] b join [CarShowRoom].[production].[models] m on b.brand_id=m.brand_id) list
	 left join 
(select brand_name, model_name, isnull(sum(list_price), 0) as January from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=1 and YEAR(order_date)=@YearSales group by brand_name, model_name) January
		on list.brand_name=January.brand_name and list.model_name=January.model_name
			left join
(select brand_name, model_name, isnull(sum(list_price), 0) as February from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=2 and YEAR(order_date)=@YearSales group by brand_name, model_name) February 
			on list.brand_name=February.brand_name and list.model_name=February.model_name
			left join 
(select brand_name, model_name, isnull(sum(list_price), 0) as March from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=3 and YEAR(order_date)=@YearSales group by brand_name, model_name) March 
			on January.brand_name=March.brand_name and January.model_name=March.model_name
			left join 
(select brand_name, model_name, isnull(sum(list_price), 0) as April from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=4 and YEAR(order_date)=@YearSales group by brand_name, model_name) April 
			on January.brand_name=April.brand_name and January.model_name=April.model_name
			left join 
(select brand_name, model_name, isnull(sum(list_price), 0) as May from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=5 and YEAR(order_date)=@YearSales group by brand_name, model_name) May 
			on January.brand_name=May.brand_name and January.model_name=May.model_name
			left join 
(select brand_name, model_name, isnull(sum(list_price), 0) as June from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=6 and YEAR(order_date)=@YearSales group by brand_name, model_name) June 
			on January.brand_name=June.brand_name and January.model_name=June.model_name
			left join 
(select brand_name, model_name, isnull(sum(list_price), 0) as July from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=7 and YEAR(order_date)=@YearSales group by brand_name, model_name) July 
			on January.brand_name=July.brand_name and January.model_name=July.model_name
			left join 
(select brand_name, model_name, isnull(sum(list_price), 0) as August from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=8 and YEAR(order_date)=@YearSales group by brand_name, model_name) August 
			on January.brand_name=August.brand_name and January.model_name=August.model_name
			left join 
(select brand_name, model_name, isnull(sum(list_price), 0) as September from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=9 and YEAR(order_date)=@YearSales group by brand_name, model_name) September 
			on January.brand_name=September.brand_name and January.model_name=September.model_name
			left join
(select brand_name, model_name, isnull(sum(list_price), 0) as October from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=10 and YEAR(order_date)=@YearSales group by brand_name, model_name) October 
			on January.brand_name=October.brand_name and January.model_name=October.model_name
			left join
(select brand_name, model_name, isnull(sum(list_price), 0) as November from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=11 and YEAR(order_date)=@YearSales group by brand_name, model_name) November 
			on January.brand_name=November.brand_name and January.model_name=November.model_name
			left join
(select brand_name, model_name, isnull(sum(list_price), 0) as December from 
  (select b.brand_name, m.model_name, o.list_price, o.order_date from [CarShowRoom].[sales].[orders] o join [CarShowRoom].[production].[models] m 
	on o.brand_id=m.brand_id and o.model_id=m.model_id join [CarShowRoom].[production].[brands] b on o.brand_id=b.brand_id) Sales 
		where month(order_date)=12 and YEAR(order_date)=@YearSales group by brand_name, model_name) December 
			on January.brand_name=December.brand_name and January.model_name=December.model_name

			select * from [CarShowRoom].[dbo].[YST]
END

GO
