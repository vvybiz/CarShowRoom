/*
--------------------------------------------------------------------
Создаем базу данных с наименованием : CarShowRoom

Запускаем данный запрос (F5)
--------------------------------------------------------------------
*/


-- create schemas
CREATE SCHEMA production;
go

CREATE SCHEMA sales;
go


CREATE TABLE production.brands (
	brand_id INT IDENTITY (1, 1) PRIMARY KEY,
	brand_name VARCHAR (255) NOT NULL
);


-- create tables
CREATE TABLE production.colors (
	color_id INT IDENTITY (1, 1) PRIMARY KEY,
	color_name VARCHAR (255) NOT NULL
);


CREATE TABLE production.models (
	model_id INT IDENTITY (1, 1) PRIMARY KEY,
	model_name VARCHAR (255) NOT NULL,
	brand_id INT NOT NULL,
	list_price DECIMAL (10, 2) NOT NULL,
	FOREIGN KEY (brand_id) REFERENCES production.brands (brand_id) ON DELETE CASCADE ON UPDATE CASCADE
);


CREATE TABLE sales.orders (
	order_id INT IDENTITY (1, 1) PRIMARY KEY,
	brand_id INT NOT NULL,
	model_id INT NOT NULL,
	color_id INT NOT NULL,
	order_date DATE NOT NULL,
	list_price DECIMAL (10, 2) NOT NULL
);
