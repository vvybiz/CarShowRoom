/*
--------------------------------------------------------------------
NameDB : CarShowRoom
--------------------------------------------------------------------
*/

use CarShowRoom

Go

SET IDENTITY_INSERT production.brands ON;  
INSERT INTO production.brands(brand_id,brand_name) VALUES(1,'Nissan')
INSERT INTO production.brands(brand_id,brand_name) VALUES(2,'Toyota')
INSERT INTO production.brands(brand_id,brand_name) VALUES(3,'Audi')
INSERT INTO production.brands(brand_id,brand_name) VALUES(4,'Hyundai')
INSERT INTO production.brands(brand_id,brand_name) VALUES(5,'Ford')
INSERT INTO production.brands(brand_id,brand_name) VALUES(6,'Volkswagen')
INSERT INTO production.brands(brand_id,brand_name) VALUES(7,'Honda')
INSERT INTO production.brands(brand_id,brand_name) VALUES(8,'BMW')
INSERT INTO production.brands(brand_id,brand_name) VALUES(9,'Mercedes-Benz')
SET IDENTITY_INSERT production.brands OFF;  

SET IDENTITY_INSERT production.colors ON;  
INSERT INTO production.colors(color_id,color_name) VALUES(1,'Red')
INSERT INTO production.colors(color_id,color_name) VALUES(2,'Orange')
INSERT INTO production.colors(color_id,color_name) VALUES(3,'Yellow')
INSERT INTO production.colors(color_id,color_name) VALUES(4,'Green')
INSERT INTO production.colors(color_id,color_name) VALUES(5,'Blue')
INSERT INTO production.colors(color_id,color_name) VALUES(6,'Black')
INSERT INTO production.colors(color_id,color_name) VALUES(7,'White')
INSERT INTO production.colors(color_id,color_name) VALUES(8,'Gray')
INSERT INTO production.colors(color_id,color_name) VALUES(9,'Brown')
SET IDENTITY_INSERT production.colors OFF;  

SET IDENTITY_INSERT production.models ON;
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(1,'350Z',1,10999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(2,'Almera',1,11999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(3,'Juke',1,12999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(4,'Navara',1,13999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(5,'Primera',1,14999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(6,'Qashqai',1,15999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(7,'Silvia',1,16999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(8,'Skyline',1,17999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(9,'Teana',1,18999.99)

INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(11,'Auris',2,10999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(12,'Avensis',2,11999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(13,'Camry',2,12999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(14,'RAV4',2,13999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(15,'Supra',2,14999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(16,'Yaris',2,15999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(17,'4Runner',2,16999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(18,'Celica',2,17999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(19,'Corolla',2,18999.99)

INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(21,'100',3,10999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(22,'80',3,11999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(23,'A4',3,12999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(24,'A6',3,13999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(25,'A7',3,14999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(26,'A8',3,15999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(27,'Q3',3,16999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(28,'Q5',3,17999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(29,'Q7',3,18999.99)

INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(31,'Elantra',4,10999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(32,'SantaFe',4,11999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(33,'Solaris',4,12999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(34,'ix35',4,13999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(35,'Creta',4,14999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(36,'Getz',4,15999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(37,'i30',4,16999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(38,'i40',4,17999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(39,'ix55',4,18999.99)

INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(41,'Focus',5,10999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(42,'Fusion',5,11999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(43,'Galaxy',5,12999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(44,'Mondeo',5,13999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(45,'Transit',5,14999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(46,'Bronco',5,15999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(47,'Escort',5,16999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(48,'Explorer',5,17999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(49,'Ka',5,18999.99)

INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(51,'Caddy',6,10999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(52,'Golf',6,11999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(53,'Jetta',6,12999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(54,'Multivan',6,13999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(55,'Passat',6,14999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(56,'Polo',6,15999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(57,'Tiguan',6,16999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(58,'Touareg',6,17999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(59,'Amarok',6,18999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(60,'Phaeton',6,19999.99)

INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(61,'Accord',7,10999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(62,'Civic',7,11999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(63,'Legend',7,12999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(64,'NSX',7,13999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(65,'Fit',7,14999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(66,'Jazz',7,15999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(67,'MDX',7,16999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(68,'Pilot',7,17999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(69,'Prelude',7,18999.99)

INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(71,'M2',8,10999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(72,'M3',8,11999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(73,'M4',8,12999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(74,'M5',8,13999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(75,'M6',8,14999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(76,'M8',8,15999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(77,'X1',8,16999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(78,'X2',8,17999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(79,'X3',8,18999.99)

INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(81,'A',9,10999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(82,'B',9,11999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(83,'C',9,12999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(84,'E',9,13999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(85,'GL',9,14999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(86,'GLK',9,15999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(87,'M',9,16999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(88,'S',9,17999.99)
INSERT INTO production.models(model_id, model_name, brand_id, list_price) VALUES(89,'GLS',9,18999.99)
SET IDENTITY_INSERT production.models OFF;

go

DECLARE @Random INT;
DECLARE @Lower INT = 1;
DECLARE @Upper INT = 9;
DECLARE @FromDate dateTIME = '20160101';
DECLARE @ToDate dateTIME = getdate();
DECLARE @Index integer = 0;

WHILE @Index < 5000
BEGIN
INSERT INTO [CarShowRoom].[sales].[orders] ([brand_id],[model_id],[color_id],[order_date],[list_price])  
VALUES (ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0),ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0),
ROUND(((@Upper - @Lower -1) * RAND() + @Lower), 0),dateadd(day,rand(checksum(newid()))*(1+datediff(day, @FromDate, @ToDate)), @FromDate),0);
  SET @index = @index + 1
END

go 

update o set o.[model_id]=m.[model_id], o.[list_price]=m.[list_price] from [CarShowRoom].[sales].[orders] o left join [CarShowRoom].[production].[models] m on o.[brand_id]=m.[brand_id] where o.[model_id]=right(m.[model_id],1)


