﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Excel = Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Excel;





namespace WpfCarShowRoom
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : System.Windows.Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }



        private void Button_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(ComboBox.Text))
            {
                System.Windows.MessageBox.Show("Не выбран год отчета");
            }
            else
            {

            System.Windows.MessageBox.Show("Создан отчет за: " + ComboBox.Text);

            string CB = ComboBox.Text;


            //Необходимо изменить подключение
            string connectionString = "Data Source=DESKTOP-ROKBB9E;Initial Catalog=CarShowRoom;Connect Timeout=15; Integrated Security=True";

            string queryEXEC = "EXEC dbo.YearSales @YearSales = " + CB;


            StringBuilder errorMessages = new StringBuilder();


            SqlConnection connection = new SqlConnection(connectionString); 
            try
            {
                connection.Open();

            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    errorMessages.Append("Index #" + i + "\n" +
                        "Message: " + ex.Errors[i].Message + "\n" +
                        "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                        "Source: " + ex.Errors[i].Source + "\n" +
                        "Procedure: " + ex.Errors[i].Procedure + "\n");
                }
                System.Windows.MessageBox.Show(errorMessages.ToString());
            }


            SqlDataAdapter dataAdapter = new SqlDataAdapter(queryEXEC, connection);

            System.Data.DataTable dataTable = new System.Data.DataTable();

            dataAdapter.Fill(dataTable);

            DataGrid.ItemsSource = dataTable.DefaultView;

            connection.Close();

            }
        }

        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            Excel.Application excel = new Excel.Application();
            
            Workbook workbook = excel.Workbooks.Add(System.Reflection.Missing.Value);
            Worksheet sheet1 = (Worksheet)workbook.Sheets[1];

            for (int j = 0; j < DataGrid.Columns.Count; j++) 
            {
                Range myRange = (Range)sheet1.Cells[1, j + 1];
                sheet1.Cells[1, j + 1].Font.Bold = true; 
                sheet1.Columns[j + 1].ColumnWidth = 15; 
                myRange.Value2 = DataGrid.Columns[j].Header;
            }

            for (int i = 0; i < DataGrid.Columns.Count; i++)
            { 
                for (int j = 0; j < DataGrid.Items.Count; j++)
                {
                    TextBlock b = DataGrid.Columns[i].GetCellContent(DataGrid.Items[j]) as TextBlock;
                    Microsoft.Office.Interop.Excel.Range myRange = (Microsoft.Office.Interop.Excel.Range)sheet1.Cells[j + 2, i + 1];
                    myRange.Value2 = b.Text;
                }
            }

            excel.Visible = true;

        }
    }
}

